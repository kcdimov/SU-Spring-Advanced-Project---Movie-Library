package bg.softuni.movies.web.rest;

import bg.softuni.movies.models.view.StatisticViewModel;
import bg.softuni.movies.services.StatisticService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;
import java.util.List;

@RestController
public class RestApiController {

    private final StatisticService statisticService;

    public RestApiController(StatisticService statisticService) {
        this.statisticService = statisticService;
    }

    @GetMapping("/api/statistic")
    @Transactional
    public ResponseEntity<List<StatisticViewModel>> getStatistic() {
        List<StatisticViewModel> statisticViewModels = this.statisticService.getStatistic();
        return new ResponseEntity<>(statisticViewModels, HttpStatus.OK);
    }

}

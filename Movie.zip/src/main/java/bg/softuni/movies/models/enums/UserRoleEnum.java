package bg.softuni.movies.models.enums;

public enum UserRoleEnum {
    ADMIN, MODERATOR, USER
}

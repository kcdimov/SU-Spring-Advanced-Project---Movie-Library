package bg.softuni.movies.models.view;

public class BaseEntityView {

    private Long id;

    public BaseEntityView() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
